from pycaw.pycaw import AudioUtilities
from socket import *
import threading
import socket
import queue
import json
import tkinter as tk
import import_ipynb
from datetime import datetime
from tkinter import ttk
from tkinter import simpledialog
from tabulate import tabulate
from tkinter import filedialog
import os
import ctypes
from pathlib import Path
from tkinter import messagebox
from tkinter import Spinbox
from tkinter import colorchooser

import les_fra_esp as esp


#servernavn
serverName = "192.168.68.102"

#serverport
serverPort = 12000

#filnavn til appikon
Icon = "ElektraLogo-01.ico"
















sanger_liste = []
logg_lock = threading.Lock()

# Sett unik AppUserModelID for prosessen (Windows trenger dette for å vise oppgavelinjeikon riktig)
try:
    app_id = "elektra.kontoret.client"  # Kan være hva som helst, men bør være unik for appen
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
except Exception as e:
    print("Kunne ikke sette AppUserModelID:", e)

# Ikonsti (absolutt bane til .ico-filen)
ikonsti = os.path.abspath(Icon)

#path til client manual, lages automatisk
Funksjoner_beskrivelse = os.path.abspath("Funksjoner_manual.txt")

def on_close():

    global serverSocket
    try:
        if serverSocket:
            serverSocket.close()
    except Exception as e:
        print("Feil ved lukking av socket:", e)
    finally:
        root_frame.destroy()

# Start hovedvindu
root_frame = tk.Tk()
root_frame.protocol("WM_DELETE_WINDOW", on_close)
root_frame.title("Kontoret Client")
root_frame.geometry("1000x800")

# Sett vanlig vindusikon
try:
    root_frame.iconbitmap(ikonsti)
except:
    pass

root = tk.Frame(root_frame)
root.pack(fill="both", expand=True)



def vis_txt_fil(filnavn):
    with open(filnavn, 'r', encoding='utf-8') as f:
        innhold = f.read()

    ny_vindu = tk.Toplevel()
    ny_vindu.title(f"Viser {filnavn}")

    text_widget = tk.Text(ny_vindu, wrap="word", font=("Courier", 10))
    text_widget.insert("1.0", innhold)
    text_widget.config(state="disabled")  # Gjør den skrivebeskyttet
    text_widget.pack(expand=True, fill="both", padx=10, pady=10)

def dummy():
    return 

def oppdater_felt(felt, nye_verdier):
    felt.config(values=nye_verdier)

def avslutt(root):
    root.destroy()

def skann_og_spill(timeout=5_000):
    logg(f"[{threading.current_thread().name}] Skanner kort", ULG)
    resultat = {"id": None, "feil": None}
    ferdig = {"status": False}  # For å se om vi fikk svar i tide

    def les():
        try:
            port = esp.finn_esp_port()
            kort_id = esp.les_fra_esp(port)
            print(f"kort ID: {kort_id}")
            resultat["id"] = kort_id
        except Exception as e:
            resultat["feil"] = str(e)
        finally:
            ferdig["status"] = True
            # Flytt root.after hit for å sikre at det alltid kjøres – selv ved feil
            root.after(0, lambda: send_til_server("spill_sang_fra_kort", ["min_database.db", resultat["id"]]))

    def timeout_sjekk():
        if not ferdig["status"]:
            messagebox.showwarning("Tidsavbrudd", "Ingen kort ble skannet innen tiden.")
    
    threading.Thread(target=les, daemon=True).start()
    root.after(timeout, timeout_sjekk)

def skann_kort(felt, root, timeout=5_000):  # timeout i millisekunder
    logg(f"[{threading.current_thread().name}] Skanner kort", ULG)
    resultat = {"id": None, "feil": None}
    ferdig = {"status": False}  # For å se om vi fikk svar i tide

    def les():
        try:
            port = esp.finn_esp_port()
            kort_id = esp.les_fra_esp(port)
            resultat["id"] = kort_id
        except Exception as e:
            resultat["feil"] = str(e)
        finally:
            ferdig["status"] = True
            root.after(0, oppdater_gui)  # Oppdater GUI i hovedtråd

    def oppdater_gui():
        if resultat["feil"]:
            messagebox.showerror("Feil", f"Feil ved skanning: {resultat['feil']}")
        elif resultat["id"]:
            felt.delete(0, "end")
            felt.insert(0, resultat["id"])
        else:
            messagebox.showinfo("Info", "Ingen ID ble funnet.")

    def timeout_sjekk():
        if not ferdig["status"]:
            messagebox.showwarning("Tidsavbrudd", "Ingen kort ble skannet innen tiden.")
    
    threading.Thread(target=les, daemon=True).start()
    root.after(timeout, timeout_sjekk)

def send_mp3(filepath):
    if not os.path.exists(filepath):
        logg(f"[{threading.current_thread().name}] Filen '{filepath}' finnes ikke.", ULG)
        return

    with socket.socket() as s:
        s.connect((serverName, serverPort))

        # Steg 1: Send kommando først
        melding = ["save_mp3", [os.path.basename(filepath), os.path.getsize(filepath)] ]
        kommando = json.dumps(melding)
        s.sendall(kommando.encode().ljust(1024))
        logg(f"[Clinet] {melding}", ULG)

        # Steg 2: Send filinnhold
        with open(filepath, "rb") as f:
            while chunk := f.read(4096):
                s.sendall(chunk)

        response_data = s.recv(4096)
        response = json.loads(response_data.decode())
        logg(f'[Server] {response}', ULG)

def sjekk_felter_og_kjør_funksjon(funksjon, widget_liste):
    import tkinter.messagebox
    
    for widget in widget_liste:
        # Hent verdien fra widget:
        if isinstance(widget, (tk.Entry, ttk.Combobox)):
            verdi = widget.get().strip()
            if not verdi:
                tkinter.messagebox.showwarning("Manglende informasjon", "Vennligst fyll ut alle feltene.")
                return False
    svar = funksjon()
    #logg(f"[{threading.current_thread().name}] {svar}", ULG)
    return True

def siste_logg_frame(root, logg_liste, antall_logg=3):
    frame = tk.Frame(root)

    tekstboks = tk.Text(frame, height=antall_logg + 1, width=80, state="disabled", bg="#f0f0f0")
    tekstboks.pack()

    def oppdater_siste_melding(ny_logg):
        tekstboks.config(state="normal")
        tekstboks.delete("1.0", tk.END)

        if ny_logg:
            # Hent de siste n loggene og snu rekkefølgen hvis ønskelig
            siste_n = reversed(ny_logg[-antall_logg:])
            tekstboks.insert(tk.END, "".join(siste_n))
        else:
            tekstboks.insert(tk.END, "Ingen loggmeldinger ennå.")

        tekstboks.config(state="disabled")

    # Oppdater første gang
    oppdater_siste_melding(logg_liste)

    return [frame, oppdater_siste_melding]

def logg(melding, navn_på_logg_menu):
    with logg_lock:
        logg_liste = navn_på_logg_menu[1]
        tekstboks = navn_på_logg_menu[2]  # tekstboksen

        nå = datetime.now().strftime("%H:%M:%S")
        
        # Konfigurer tagger (gjøres én gang)
        tekstboks.tag_configure("tid", foreground="blue")  # Tidspunkt i grått
        tekstboks.tag_configure("melding", foreground="black")  # Melding i svart (valgfritt)

        logg_liste.append(f"{nå}; {melding}\n")

        tekstboks.config(state="normal")

        # Skriv selve meldingen med melding-tag
        tekstboks.insert("1.0", f"{melding}\n", "melding")

        # Skriv tidspunkt med tag
        tekstboks.insert("1.0", f"{nå}; ", "tid")

        tekstboks.see(tk.END)
        tekstboks.config(state="disabled")

        SLG[1](navn_på_logg_menu[1])

def uppdate_variable(varnavn: str, verdi):
    globals()[varnavn] = verdi.get()
    logg(f"[{threading.current_thread().name}] {varnavn} er nå: {globals()[varnavn]}", ULG)

def dominate_frame(root, frames):
    for widget in root.winfo_children():
        widget.pack_forget()
    for frame in frames:
        frame.pack(pady=1)

def laas_opp(root, frame):
    passord = simpledialog.askstring("Passord", "Skriv inn passord for å låse opp:", show="*")
    if passord == "elektra":  # Sett ditt passord her
        dominate_frame(root, frame)
    else:
        tk.messagebox.showerror("Feil passord", "Passordet er feil!")
    
def sett_oppgavelinjeikon():
    try:
        hwnd = root.winfo_id()
        hicon = ctypes.windll.user32.LoadImageW(0, ikonsti, 1, 0, 0, 0x00000010)
        if not hicon:
            logg(f"[{threading.current_thread().name}] Kunne ikke laste ikon via LoadImageW", ULG)
            return
        WM_SETICON = 0x0080
        ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 0, hicon)  # ICON_SMALL
        ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 1, hicon)  # ICON_BIG
        logg(f"[{threading.current_thread().name}] Oppgavelinjeikon satt", ULG)
    except Exception as e:
        logg(f"[{threading.current_thread().name}] Feil ved oppgavelinjeikon: {e}", ULG)

def send_til_server(funksjon, sentence):
    try:
        # Lag socket og koble til server
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as clientSocket:
            clientSocket.connect((serverName, serverPort))

            # Lag melding og send
            melding = [funksjon, sentence]
            data = json.dumps(melding).encode()

            logg(f'[Client] {melding}', ULG)
            clientSocket.sendall(data)

            # Motta og dekod svar
            response_data = clientSocket.recv(4096)
            response = json.loads(response_data.decode())

            logg(f'[Server] {response}', ULG)
            return response

    except Exception as e:
        feilmelding = f"Kunne ikke koble til server ({serverName}:{serverPort}): {e}"
        logg(f"[{threading.current_thread().name}] {feilmelding}", ULG)
        

def vis_liste(list):
    
    logg(f"[{threading.current_thread().name}] Viser sanger fra database", ULG)

    ny_vindu = tk.Toplevel()
    ny_vindu.title("Sanger i databasen")

    listbox = tk.Listbox(ny_vindu, width=60, height=20)
    for sang in list:
        listbox.insert(tk.END, sang)
    listbox.pack(padx=10, pady=10, fill="both", expand=True)

    # Scrollbar (valgfritt)
    scrollbar = tk.Scrollbar(ny_vindu)
    scrollbar.pack(side="right", fill="y")
    listbox.config(yscrollcommand=scrollbar.set)
    scrollbar.config(command=listbox.yview)

def vis_database():
    rader = send_til_server("get_database", ["min_database.db"])[1]
    kolonner = ["ID", "KortID", "KortNavn", "Sang", "Start", "Volum", "Stopp_spotify", "Scene", "Broadcast"]

    # Lag tabellen som tekst
    tabell_tekst = tabulate(rader, headers=kolonner, tablefmt="grid")
    logg(f"[{threading.current_thread().name}] Viser Database", ULG)

    # Lag nytt vindu
    ny_vindu = tk.Toplevel()
    ny_vindu.title("Databasetabell")

    # Legg tabellen inn i en Text-widget (for lett rulling og kopiering)
    text_widget = tk.Text(ny_vindu, wrap="none", width=120, height=20)
    text_widget.insert("1.0", tabell_tekst)
    text_widget.config(state="disabled")  # Gjør den skrivebeskyttet
    text_widget.pack(padx=10, pady=10)

def bla_gjennom():
    filsti = filedialog.askopenfilename(
        title="Velg en MP3-fil",
        filetypes=[("MP3-filer", "*.mp3")]
    )
    if filsti:
        print("funnet filsti")
        return filsti

def oppdater_sanger_lister():
    try:
        sanger_liste = send_til_server("get_lydklipp", [None])
    finally:
        oppdater_felt(velg_sang, sanger_liste)
        oppdater_felt(Sang, sanger_liste)

























# menyer--------------------------------------------------------------------------------------------------

def main_menu(root):
    bredde = 15
    main_frame = tk.Frame(root)
    tk.Button(main_frame, text="Avslutt", width=bredde, command=lambda: avslutt(root_frame)).pack(pady=1, side="bottom")
    tk.Button(main_frame, text="Logg", width=bredde, command=lambda: dominate_frame(root, [ULG[0]])).pack(pady=1)
    tk.Button(main_frame, text="Lyd kontroller", width=bredde, command=lambda: dominate_frame(root, [KM])).pack(pady=1)
    tk.Button(main_frame, text="Behandle database", width=bredde, command=lambda: dominate_frame(root, [Behandle_kort_menu_frame])).pack(pady=1)
    tk.Button(main_frame, text="Send MP3", width=bredde, command=lambda: dominate_frame(root, [send_mp3_menu_frame])).pack(pady=1)
    tk.Button(main_frame, text="Innstillinger", width=bredde, command=lambda: dominate_frame(root, [SM])).pack(pady=1)
    #tk.Button(main_frame, text="Lys kontroller", width=bredde, command=lambda: dominate_frame(root, [Lys_menu])).pack(pady=1)
    return main_frame

def settings_menu(root):
    bredde = 15
    main_frame = tk.Frame(root)
    tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: dominate_frame(root, [HS])).pack(pady=1)

    tk.Button(main_frame, text="Client manual", width=bredde, command=lambda: vis_txt_fil(Funksjoner_beskrivelse)).pack(pady=1)

    return main_frame

def lyd_kontroll_menu(root):
    global sanger_liste
    bredde = 15

    main_frame = tk.Frame(root, bd=2, relief="groove")
    main_frame.pack(fill="both", expand=True)
    tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

    width = 300
    height = 540
    frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

    frame1.pack_propagate(False)
    frame2.pack_propagate(False)
    frame3.pack_propagate(False)

    # Funksjon for å spørre om passord og vise beskyttede Frames
    def avansert_kontroll_menu():
            frame2.pack(side="left", padx=5, pady=5)
            frame3.pack(side="left", padx=5, pady=5)
            avansert_knapp.forget()

    def tilbake():
        frame2.forget()
        frame3.forget()
        avansert_knapp.pack(pady=10)
        dominate_frame(root, [HS])

    def oppdater_sanger_liste():
        global sanger_liste
        sanger_liste = send_til_server("get_lydklipp", [None])
        oppdater_felt(velg_sang, sanger_liste)
        oppdater_felt(Sang, sanger_liste)


    # Knapp for å låse opp frame2 og frame3
    avansert_knapp_frame = tk.Frame(main_frame)
    avansert_knapp_frame.pack(pady=10, side="bottom")
    avansert_knapp = tk.Button(avansert_knapp_frame, text="Mer", width=bredde, command=avansert_kontroll_menu)
    avansert_knapp.pack(pady=10)

    frame1.pack(side="left", padx=5, pady=5)
    #frame2.pack(side="left", padx=5, pady=5)
    #frame3.pack(side="left", padx=5, pady=5)


    #frame 1
    tk.Label(frame1, text=f"Musikkspiller", fg="black").pack(anchor="w", pady=5)
    
    tk.Button(frame1, text="Scan og spill sang", width=bredde, command=lambda: skann_og_spill()).pack(pady=1)
    tk.Button(frame1, text="Stopp sang", width=bredde, command=lambda: send_til_server("spill_sang", [None, False, 1.0, funksjons_mapping_pause_spotify[pause_spotify.get()], None, None])).pack(pady=5, side="bottom")
    tk.Button(frame1, text="Start sang", width=bredde, command=lambda: send_til_server("spill_sang", [velg_sang.get().strip(), True, float(velg_volum.get().strip()), funksjons_mapping_pause_spotify[pause_spotify.get()], velg_scene.get().strip(), velg_broadcast.get().strip()])).pack(pady=1, side="bottom")
    
    velg_sang_frame = tk.Frame(frame1)
    velg_sang_frame.pack(pady=5)

    global velg_sang
    tk.Label(velg_sang_frame, text="Sang:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
    velg_sang = ttk.Combobox(velg_sang_frame, width=15, values=sanger_liste)
    velg_sang.grid(row=0, column=1, padx=5, pady=2)

    volume_liste = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    tk.Label(velg_sang_frame, text="Volum:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
    velg_volum = ttk.Combobox(velg_sang_frame, width=15, values=volume_liste, state="readonly")
    velg_volum.grid(row=1, column=1, padx=5, pady=2)

    funksjons_mapping_pause_spotify = {"Stopp": 1, "Ikke Stopp": 0}
    tk.Label(velg_sang_frame, text="Spotify:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
    pause_spotify = ttk.Combobox(velg_sang_frame, width=15, values=list(funksjons_mapping_pause_spotify.keys()), state="readonly")
    pause_spotify.insert(0, "Stopp")
    pause_spotify.grid(row=2, column=1, padx=5, pady=2)

    scene_liste = [None]
    tk.Label(velg_sang_frame, text="Scene:").grid(row=3, column=0, sticky="w", padx=5, pady=2)
    velg_scene = ttk.Combobox(velg_sang_frame, width=15, values=scene_liste)
    velg_scene.grid(row=3, column=1, padx=5, pady=2)

    broadcast_liste = [None]
    tk.Label(velg_sang_frame, text="Broadcast:").grid(row=4, column=0, sticky="w", padx=5, pady=2)
    velg_broadcast = ttk.Combobox(velg_sang_frame, width=15, values=broadcast_liste)
    velg_broadcast.grid(row=4, column=1, padx=5, pady=2)
    
    #frame 2
    tk.Label(frame2, text=f"Oppdateringer", fg="black").pack(anchor="w", pady=5)

    tk.Button(frame2, text="Oppdater sanger", width=bredde, command=lambda: oppdater_sanger_liste()).pack(pady=1)


    

    #frame 3

    return main_frame

def behandle_kort_menu(root):
    global sanger_liste
    bredde = 15

    main_frame = tk.Frame(root, bd=2, relief="groove")
    main_frame.pack(fill="both", expand=True)
    tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

    width = 300
    height = 540
    frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

    frame1.pack_propagate(False)
    frame2.pack_propagate(False)
    frame3.pack_propagate(False)

    # Funksjon for å spørre om passord og vise beskyttede Frames
    def avansert_kontroll_menu():
            frame2.pack(side="left", padx=5, pady=5)
            frame3.pack(side="left", padx=5, pady=5)
            avansert_knapp.forget()
    
    def tilbake():
        frame2.forget()
        frame3.forget()
        avansert_knapp.pack(pady=10)
        dominate_frame(root, [HS])

    def oppdater_sanger_liste():
        global sanger_liste
        sanger_liste = send_til_server("get_lydklipp", [None])
        oppdater_felt(velg_sang, sanger_liste)
        oppdater_felt(Sang, sanger_liste)

    # Knapp for å låse opp frame2 og frame3
    avansert_knapp_frame = tk.Frame(main_frame)
    avansert_knapp_frame.pack(pady=10, side="bottom")
    avansert_knapp = tk.Button(avansert_knapp_frame, text="Mer", width=bredde, command=avansert_kontroll_menu)
    avansert_knapp.pack(pady=10)

    frame1.pack(side="left", padx=5, pady=5)
    #frame1.pack(side="left", padx=5, pady=5)
    #frame3.pack(side="left", padx=5, pady=5)

    #frame 1
    tk.Label(frame1, text=f"Behandle database", fg="black").pack(anchor="w", pady=5)
    tk.Button(frame1, text="Scan kort", width=bredde, command=lambda: skann_kort(IDe, root_frame)).pack(pady=1)
   
    id_navn_startsignal = tk.Frame(frame1)
    id_navn_startsignal.pack(pady=5)

    tk.Label(id_navn_startsignal, text="ID:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
    IDe = tk.Entry(id_navn_startsignal, width=18)
    IDe.grid(row=0, column=1, padx=5, pady=2)

    tk.Label(id_navn_startsignal, text="Navn:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
    Navn = tk.Entry(id_navn_startsignal, width=18)
    Navn.grid(row=1, column=1, padx=5, pady=2)

    global Sang
    tk.Label(id_navn_startsignal, text="Sang:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
    Sang = ttk.Combobox(id_navn_startsignal, width=15, values=sanger_liste)
    Sang.grid(row=2, column=1, padx=5, pady=2) 

    funksjons_mapping = {"Start": 1, "Stopp": 0}
    tk.Label(id_navn_startsignal, text="Funksjon:").grid(row=3, column=0, sticky="w", padx=5, pady=2)
    Funksjon = ttk.Combobox(id_navn_startsignal, width=15, values=list(funksjons_mapping.keys()), state="readonly")
    Funksjon.grid(row=3, column=1, padx=5, pady=2)
    
    volume_liste = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
    tk.Label(id_navn_startsignal, text="Volum:").grid(row=4, column=0, sticky="w", padx=5, pady=2)
    volume = ttk.Combobox(id_navn_startsignal, width=15, values=volume_liste, state="readonly")
    volume.grid(row=4, column=1, padx=5, pady=2)

    stopp_spotify_map = {"Stopp": 1, "Ikke Stopp": 0}
    tk.Label(id_navn_startsignal, text="Spotify:").grid(row=5, column=0, sticky="w", padx=5, pady=2)
    stopp_spotify = ttk.Combobox(id_navn_startsignal, width=15, values=list(stopp_spotify_map.keys()), state="readonly")
    stopp_spotify.grid(row=5, column=1, padx=5, pady=2)

    scene_liste = [None]
    tk.Label(id_navn_startsignal, text="Scene:").grid(row=6, column=0, sticky="w", padx=5, pady=2)
    velg_scene = ttk.Combobox(id_navn_startsignal, width=15, values=scene_liste)
    velg_scene.grid(row=6, column=1, padx=5, pady=2)

    broadcast_liste = [None]
    tk.Label(id_navn_startsignal, text="Broadcast:").grid(row=7, column=0, sticky="w", padx=5, pady=2)
    velg_broadcast = ttk.Combobox(id_navn_startsignal, width=15, values=broadcast_liste)
    velg_broadcast.grid(row=7, column=1, padx=5, pady=2)

    tk.Button(frame1, text="Legg til kort", width=bredde, command=lambda: sjekk_felter_og_kjør_funksjon(lambda: send_til_server("save_card", ["min_database.db", IDe.get().strip(), Navn.get().strip(), Sang.get().strip(), funksjons_mapping[Funksjon.get()], volume.get().strip(), stopp_spotify_map.get(stopp_spotify.get().strip(), 0), velg_scene.get().strip(), velg_broadcast.get().strip()]), [IDe, Navn, Funksjon, volume, stopp_spotify, velg_scene, velg_broadcast])).pack(pady=5, side="bottom")
    tk.Button(frame1, text="Slett kort", width=bredde, command=lambda: sjekk_felter_og_kjør_funksjon(lambda: send_til_server("delete_card", ["min_database.db", IDe.get().strip(), Navn.get().strip()]), [1])).pack(pady=1, side="bottom")
    tk.Button(frame1, text="Se database", width=bredde, command=lambda: vis_database()).pack(pady=5, side="bottom")

    #frame 2
    tk.Label(frame2, text=f"Oppdateringer", fg="black").pack(anchor="w", pady=5)

    tk.Button(frame2, text="Oppdater sanger", width=bredde, command=lambda: oppdater_sanger_liste()).pack(pady=1)


    #frame 3

    return main_frame

def send_mp3_menu(root):
    global sanger_liste
    bredde = 15

    main_frame = tk.Frame(root, bd=2, relief="groove")
    main_frame.pack(fill="both", expand=True)
    tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

    width = 300
    height = 540
    frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

    frame1.pack_propagate(False)
    frame2.pack_propagate(False)
    frame3.pack_propagate(False)

    # Funksjon for å spørre om passord og vise beskyttede Frames
    def avansert_kontroll_menu():
            frame2.pack(side="left", padx=5, pady=5)
            frame3.pack(side="left", padx=5, pady=5)
            avansert_knapp.forget()
    
    def tilbake():
        frame2.forget()
        frame3.forget()
        avansert_knapp.pack(pady=10)
        dominate_frame(root, [HS])

    def insert_filsti(felt):
        filsti = bla_gjennom()
        if filsti:  # bare hvis noe ble valgt
            felt.delete(0, tk.END)  # fjern gammel verdi
            felt.insert(0, filsti)


    # Knapp for å låse opp frame2 og frame3
    avansert_knapp_frame = tk.Frame(main_frame)
    avansert_knapp_frame.pack(pady=10, side="bottom")
    avansert_knapp = tk.Button(avansert_knapp_frame, text="Mer", width=bredde, command=avansert_kontroll_menu)
    avansert_knapp.pack(pady=10)

    frame1.pack(side="left", padx=5, pady=5)
    #frame1.pack(side="left", padx=5, pady=5)
    #frame3.pack(side="left", padx=5, pady=5)

    #frame 1
    tk.Label(frame1, text=f"Send MP3", fg="black").pack(anchor="w", pady=5)

    tk.Button(frame1, text="Bla gjennom filer", width=bredde, command=lambda: insert_filsti(Filsti)).pack(pady=5)

    underframe1 = tk.Frame(frame1)
    underframe1.pack(pady=5)

    tk.Label(underframe1, text="Filsti:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
    Filsti = tk.Entry(underframe1, width=18)
    Filsti.grid(row=1, column=1, padx=5, pady=2)
 
    tk.Button(frame1, text="Send MP3-fil", width=bredde, command=lambda: send_mp3(Filsti.get())).pack(pady=5, side="bottom")
    tk.Button(frame1, text="Vis lagrede sanger", width=bredde, command=lambda: vis_liste(send_til_server("get_lydklipp", [None]))).pack(pady=5, side="bottom")

    #frame 2
    

    #frame 3

    return main_frame


def logg_menu(root):
    bredde = 15
    main_frame = tk.Frame(root)
    logg_innhold = []
    tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: dominate_frame(root, [HS])).pack(pady=1)
    # Ramme som holder tekst og scrollbar
    frame = tk.Frame(main_frame)
    scrollbar = tk.Scrollbar(frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    # Tekstboks
    tekstboks = tk.Text(frame, wrap=tk.WORD, yscrollcommand=scrollbar.set, width=100, height=25)
    tekstboks.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.config(command=tekstboks.yview)
    tekstboks.config(state="disabled")
    frame.pack()
    return [main_frame, logg_innhold, tekstboks]


def kobler_til_server_menu(root):
    main_frame = tk.Frame(root, bd=2, relief="groove")
    main_frame.pack(fill="both", expand=True)
    tk.Label(main_frame, text="Forsøker å kontakte Serveren").grid(row=0, column=0, sticky="w", padx=5, pady=2)

    return main_frame
    

HS = main_menu(root)
ULG = logg_menu(root)
SM = settings_menu(root)
KM = lyd_kontroll_menu(root)
Behandle_kort_menu_frame = behandle_kort_menu(root)
send_mp3_menu_frame = send_mp3_menu(root)
SLG = siste_logg_frame(root_frame, ULG[1], 3)
kobler_til_server_frame = kobler_til_server_menu(root)

SLG[0].pack(pady=10, side="bottom")



def start_up_menu(root):
    bredde = 15

    main_frame = tk.Frame(root, bd=2)
    main_frame.pack(fill="both", expand=True)

    # Funksjoner
    def start_client():
        global serverPort
        global serverName

        def åpne_client():
            oppdater_sanger_lister()
            dominate_frame(root, [HS])

        dominate_frame(root, [kobler_til_server_frame])

        serverPort = int(server_port.get())
        serverName = Server_IP.get()

        åpne_client_thread = threading.Thread(target=åpne_client)
        åpne_client_thread.start()
        
    # OK-knapp
    tk.Button(main_frame, text="OK", width=bredde, command=start_client).pack(pady=10)

    width = 300
    height = 540
    frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame1.pack(side="left", padx=5, pady=5)
    frame1.pack_propagate(False)

    # Frame 1
    tk.Label(frame1, text="Initialisering", fg="black").pack(anchor="w", pady=5)

    # Legg inn portinput i en egen underframe for struktur
    port_frame = tk.Frame(frame1)
    port_frame.pack(anchor="w", pady=2)

    tk.Label(port_frame, text="Server IP:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
    Server_IP = ttk.Entry(port_frame, width=15)
    Server_IP.grid(row=0, column=1, padx=5, pady=2)
    Server_IP.insert(0, serverName)

    tk.Label(port_frame, text="Server port:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
    server_port = ttk.Entry(port_frame, width=15)
    server_port.grid(row=1, column=1, padx=5, pady=2)
    server_port.insert(0, serverPort)

    return main_frame


Start_menu = start_up_menu(root)
dominate_frame(root, [Start_menu])



root_frame.after(200, sett_oppgavelinjeikon)
root_frame.mainloop()