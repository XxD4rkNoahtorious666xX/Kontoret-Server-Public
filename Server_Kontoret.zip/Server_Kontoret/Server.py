import time
import pyautogui
import pygame
from pycaw.pycaw import AudioUtilities
from socket import *
import threading
import socket
import queue
import json
import pythoncom
import tkinter as tk
from datetime import datetime
from tkinter import ttk
from tkinter import simpledialog
from tabulate import tabulate
import os
import ctypes
import glob
from tkinter import messagebox
from tkinter import Spinbox
from tkinter import colorchooser
from pythonosc.udp_client import SimpleUDPClient

import les_fra_esp as esp
import database as db
import config as con

pygame.init()
pygame.mixer.init()


#serverporten
serverPort = con.serverPort

#path til mappen som inneholder lydklippene
path_til_lydklipp = con.path_til_lydklipp

#komunikasjon med QLC+
QLC_IP = con.QLC_IP
QLC_port = con.QLC_port

#filnavn til appikon
Icon = con.Icon















#liste med sanger som brukes i server UI, blir fylt inn automatisk
sanger_liste = []

ESP_liste = ["Tak"]

stopp_musikk = False
Musikk_Spilles = False
gjeldende_sang = None

godta_kort = True
godta_knapp = True
godta_MP3 = True

sang_queue = queue.Queue()
scene_queue = queue.Queue()

logg_lock = threading.Lock()





def on_close():

    global serverSocket
    try:
        if serverSocket:
            serverSocket.close()
    except Exception as e:
        print("Feil ved lukking av socket:", e)
    finally:
        root_frame.destroy()



    # Sett unik AppUserModelID for prosessen (Windows trenger dette for å vise oppgavelinjeikon riktig)

try:
    app_id = "elektra.kontoret.server"  # Kan være hva som helst, men bør være unik for appen
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
except Exception as e:
    print("Kunne ikke sette AppUserModelID:", e)

# Ikonsti (absolutt bane til .ico-filen)
ikonsti = os.path.abspath(Icon)

# Start hovedvindu
root_frame = tk.Tk()
root_frame.protocol("WM_DELETE_WINDOW", on_close)
root_frame.title("Kontoret Server")
root_frame.geometry("1000x800")

# Sett vanlig vindusikon
root_frame.iconbitmap(ikonsti)

root = tk.Frame(root_frame)
root.pack(fill="both", expand=True)



def sett_oppgavelinjeikon():
        try:
            hwnd = root.winfo_id()
            hicon = ctypes.windll.user32.LoadImageW(0, ikonsti, 1, 0, 0, 0x00000010)
            if not hicon:
                print(f"[{threading.current_thread().name}] Kunne ikke laste ikon via LoadImageW")
                return
            WM_SETICON = 0x0080
            ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 0, hicon)  # ICON_SMALL
            ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 1, hicon)  # ICON_BIG
        except Exception as e:
            print("Feil", e)
            
def dominate_frame(root, frames):
            for widget in root.winfo_children():
                widget.pack_forget()
            for frame in frames:
                frame.pack(pady=1)

def main():

    global stopp_musikk
    global Musikk_Spilles
    global gjeldende_sang

    global godta_kort
    global godta_knapp
    global godta_MP3

    global serverSocket

    global sang_queue
    global socket_queue

    serverSocket = socket.socket(AF_INET,SOCK_STREAM)
    serverSocket.bind(('',serverPort))
    serverSocket.listen(1)

    #path til client manual, lages automatisk
    Funksjoner_beskrivelse = os.path.abspath("Funksjoner_manual.txt")

    def oppdater_sanger():
        global sanger_liste
        sanger_liste = []
        mp3_filer = glob.glob(os.path.join(path_til_lydklipp, "*.mp3"))
        for fil in mp3_filer:
            filnavn = os.path.splitext(os.path.basename(fil))[0]
            sanger_liste.append(filnavn)

    oppdater_sanger()

    def oppdater_felt(felt, nye_verdier):
        felt.config(values=nye_verdier)

    def get_spotify_volume():
        sessions = AudioUtilities.GetAllSessions()
        for session in sessions:
            process = session.Process
            if process and "spotify" in process.name().lower():
                volume_interface = session.SimpleAudioVolume
                volume = volume_interface.GetMasterVolume()  # Henter volumet
                return volume
        logg(f"[{threading.current_thread().name}] Spotify Volum ble ikke funnet.", ULG)
        return None

    def set_all_spotify_volumes(level):  # nivå fra 0.0 til 1.0
        sessions = AudioUtilities.GetAllSessions()
        funnet = False
        for session in sessions:
            process = session.Process
            display_name = session.DisplayName

            if process and "spotify" in process.name().lower():
                session.SimpleAudioVolume.SetMasterVolume(level, None)
        
                logg(f"[{threading.current_thread().name}] Volum satt til {int(level * 100)}% for: {display_name or process.name()}", ULG)
                funnet = True

        if not funnet:
            logg(f"[{threading.current_thread().name}] Fant ingen Spotify-sesjoner.", ULG)

    def spotify_is_running():
        sessions = AudioUtilities.GetAllSessions()
        for session in sessions:
            process = session.Process
            if process and process.name().lower().startswith("spotify"):
                if session.State == 1:  # 1 = Audio is playing
                    return True
        return False

    def pause_spotify():
        """Pauser Spotify ved å sende Play/Pause tastetrykk"""
        if spotify_is_running() == True:
            pyautogui.press('playpause')
            time.sleep(1)

    def start_spotify():
        """Gjenopptar Spotify ved å sende Play/Pause tastetrykk"""
        if (spotify_is_running() == False):
            pyautogui.press('playpause')

    def SongToPath(name):
        global path_til_lydklipp
        path = path_til_lydklipp
        return path + name + ".mp3"

    def finnes_sang(sangnavn):
        """Sjekker om sangfilen finnes i mappen."""
        full_path = SongToPath(sangnavn)
        if os.path.isfile(full_path):
            return True
        else:
            logg(f"[{threading.current_thread().name}] Sangfilen '{sangnavn}.mp3' finnes ikke i path: {full_path}", ULG)
            return False
        
    def send_osc_til_qlc(navn, value):
        logg(f"[{threading.current_thread().name}] Sender [{navn}, {value}] til QLC+ (Server: {QLC_IP}, port: {QLC_port})", ULG)
        SimpleUDPClient(QLC_IP, QLC_port).send_message(navn, value)
            
    def play_clip(data):
        global stopp_musikk
        global Musikk_Spilles
        global gjeldende_sang
        pythoncom.CoInitialize()

        """Spiller av lydklipp og venter til det er ferdig"""
        volume = get_spotify_volume()
        was_spotity_running = spotify_is_running()
        if data[3]:
            set_all_spotify_volumes(0.0)
        
        gjeldende_sang = data[0]
        pygame.mixer.music.load(SongToPath(data[0]))
        pygame.mixer.music.set_volume(data[2])
        Musikk_Spilles = True
        pygame.mixer.music.play()

        input = data[4]
        logg(f"[{threading.current_thread().name}] Aktiverer input: {input} i QLC+", ULG)
        scene_queue.put([input, 255]) #aktiverer signal i QLC+

        while pygame.mixer.music.get_busy():
            time.sleep(0.1)
            if (spotify_is_running() and data[3]):
                logg(f"[{threading.current_thread().name}] Spotify kjører, pauser...", ULG)
                pause_spotify()
            if stopp_musikk == True:
                stopp_musikk = False
                pygame.mixer.music.stop()
                break

        Musikk_Spilles = False
        gjeldende_sang = None

        logg(f"[{threading.current_thread().name}] Lydklipp ferdig, gjenopptar Spotify...", ULG)
        set_all_spotify_volumes(1.0)
        if was_spotity_running:
            start_spotify()

        logg(f"[{threading.current_thread().name}] Deaktiverer input: {input}, i QLC+", ULG)
        scene_queue.put([input, 0]) #aktiverer signal i QLC+

    def queue_song(sentence):
        global stopp_musikk
        global Musikk_Spilles
        global gjeldende_sang

        if sentence[0] is not None and not finnes_sang(sentence[0]):
            return 2
        
        if Musikk_Spilles == False:
            if sentence[1] == True:
                sang_queue.put(sentence)
                return 1
                    
        elif Musikk_Spilles == True and (sentence[0] == gjeldende_sang or sentence[0] == None):
            if sentence[1] == False:
                logg(f"[{threading.current_thread().name}] Sang Stoppes", ULG)
                stopp_musikk = True
                return 3
            
        if sentence[0] != gjeldende_sang and sentence[1] == False:
            return 4
        
        if sentence[0] == None:
            return 2

        logg(f"[{threading.current_thread().name}] Sang: {sentence[0]} kunne ikke spilles", ULG)
        return 2

    def spill_sang_fra_kort(parametre):
        if(db.Sjekk_KortID_database(parametre[0], parametre[1])[0] == True):
            sang_para = db.hent_sang_fra_kortid(parametre[0], parametre[1])
            print(sang_para)
            return [True, queue_song([sang_para[0], sang_para[1], sang_para[2], sang_para[3], sang_para[4]])]
        
        return [False, None]

    def motta_mp3(connectionSocket, filnavn, lengde):
        global path_til_lydklipp
        full_sti = os.path.join(path_til_lydklipp, f"M_{filnavn}")
        
        with open(full_sti, "wb") as f:
            mottatt = 0
            while mottatt < lengde:
                chunk = connectionSocket.recv(min(4096, lengde - mottatt))
                if not chunk:
                    break
                f.write(chunk)
                mottatt += len(chunk)
        oppdater_sanger()
        oppdater_felt(velg_sang, sanger_liste)
        oppdater_felt(Sang, sanger_liste)
        logg(f"[{threading.current_thread().name}] Mottok MP3-fil: {filnavn}, lagrer som: {full_sti}", ULG)
        
        return f"MP3-fil mottatt og lagret"

    def send_tabell(connectionSocket, database):
        rader = db.Hent_tabell(database)
        melding = ["OK", rader]
        connectionSocket.sendall(json.dumps(melding).encode())
        return f"Database: {database} sendt"

    #--------------------------------------------------------------------------------------------------------------------

    def kjør_funksjon(funksjon_navn, parametre, conn):

        #funksjon 1
        if(funksjon_navn == "spill_sang"):
            if godta_knapp:
                return queue_song(parametre)
        
            elif(not godta_knapp):
                if parametre[1] == True:
                    return 2
                elif parametre[1] == False:
                    return 4
                
        #funksjon 2
        elif(funksjon_navn == "save_card"):
            return db.save_card(parametre[0], parametre[1], parametre[2], parametre[3], parametre[4], parametre[5], parametre[6], parametre[7])

        #funksjon 3
        elif(funksjon_navn == "delete_card"):
            return db.delete_card(parametre[0], parametre[1], parametre[2])

        #funksjon 4
        elif(funksjon_navn == "spill_sang_fra_kort" and godta_kort):
            return spill_sang_fra_kort(parametre)
        
        #funksjon 5
        elif(funksjon_navn == "get_database"):
            return send_tabell(conn, parametre[0])

        #funksjon 6
        elif(funksjon_navn == "save_mp3"):
            return motta_mp3(conn, parametre[0], parametre[1])
        
        #funksjon 7
        elif(funksjon_navn == "get_lydklipp"):
            oppdater_sanger()
            return sanger_liste
            
    def scan_og_spill():
        IDe = esp.les_fra_esp(esp.finn_esp_port())
        kjør_funksjon("spill_sang_fra_kort", ["min_database.db", IDe])

    def vis_database(database):
        rader = db.Hent_tabell(database)
        kolonner = ["ID", "KortID", "KortNavn", "Sang", "Start", "Volum", "Stopp_spotify", "Scene"]

        # Lag tabellen som tekst
        tabell_tekst = tabulate(rader, headers=kolonner, tablefmt="grid")
        logg(f"[{threading.current_thread().name}] Viser Database", ULG)

        # Lag nytt vindu
        ny_vindu = tk.Toplevel()
        ny_vindu.title("Databasetabell")

        # Legg tabellen inn i en Text-widget (for lett rulling og kopiering)
        text_widget = tk.Text(ny_vindu, wrap="none", width=80, height=20)
        text_widget.insert("1.0", tabell_tekst)
        text_widget.config(state="disabled")  # Gjør den skrivebeskyttet
        text_widget.pack(padx=10, pady=10)

    def vis_txt_fil(filnavn):
        with open(filnavn, 'r', encoding='utf-8') as f:
            innhold = f.read()

        ny_vindu = tk.Toplevel()
        ny_vindu.title(f"Viser {filnavn}")

        text_widget = tk.Text(ny_vindu, wrap="word", font=("Courier", 10))
        text_widget.insert("1.0", innhold)
        text_widget.config(state="disabled")  # Gjør den skrivebeskyttet
        text_widget.pack(expand=True, fill="both", padx=10, pady=10)

    def aktiver_input_i_QLC(input, value):
        client = SimpleUDPClient(QLC_IP, QLC_port)
        if input:
            logg(f"[{threading.current_thread().name}] Sender: [{input}, {value}] til QLC+ via OSC", ULG)
            client.send_message(input, value)




    def Server():
        while True:
            logg(f"[{threading.current_thread().name}] Ready to receive", ULG)
            connectionSocket, addr = serverSocket.accept()

            # 1: Ta imot JSON-kommando først (f.eks. 1024 bytes)
            data = connectionSocket.recv(1024).decode().strip()
            sentence = json.loads(data)
            logg(f"[{threading.current_thread().name}] Fikk melding: {sentence}", ULG)

            kommando, param = sentence[0], sentence[1]
            try:
                svar = kjør_funksjon(kommando, param, connectionSocket)
                # Svar tilbake
                response = svar
                logg(f"[{threading.current_thread().name}] Sender respons: {response}", ULG)

            finally:
                connectionSocket.send(json.dumps(response).encode())
                connectionSocket.close()                


    def musikkspiller():
        while True:
            melding = sang_queue.get()  # Venter til noe legges i køa
            logg(f"[{threading.current_thread().name}] Spiller sang med parametre: {melding}", ULG)
            
            if melding[1] == True:
                logg(f"[{threading.current_thread().name}] Spiller Lydklipp: {SongToPath(melding[0])}", ULG)

                play_clip(melding)


    def QLC_pluss_manager():
        while True:
            input = scene_queue.get()
            aktiver_input_i_QLC(input[0], input[1])
        










































    

    def hent_ip_adresse():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # Kobler til en "dummy" ekstern IP for å finne lokal IP
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except Exception:
            ip = "Ukjent"
        finally:
            s.close()
        return ip

    def dummy():
        return 

    def skann_og_spill(timeout=5_000):
        logg(f"[{threading.current_thread().name}] Skanner kort", ULG)
        resultat = {"id": None, "feil": None}
        ferdig = {"status": False}  # For å se om vi fikk svar i tide

        def les():
            try:
                port = esp.finn_esp_port()
                kort_id = esp.les_fra_esp(port)
                resultat["id"] = kort_id
            except Exception as e:
                resultat["feil"] = str(e)
            finally:
                ferdig["status"] = True
                # Bruk resultat["id"] i stedet for kort_id direkte
                root.after(0, lambda: spill_sang_fra_kort(["min_database.db", resultat["id"]]))

        def timeout_sjekk():
            if not ferdig["status"]:
                messagebox.showwarning("Tidsavbrudd", "Ingen kort ble skannet innen tiden.")

        threading.Thread(target=les, daemon=True).start()
        root.after(timeout, timeout_sjekk)

    def skann_kort(felt, root, timeout=5_000):  # timeout i millisekunder
        logg(f"[{threading.current_thread().name}] Skanner kort", ULG)
        resultat = {"id": None, "feil": None}
        ferdig = {"status": False}  # For å se om vi fikk svar i tide

        def les():
            try:
                port = esp.finn_esp_port()
                kort_id = esp.les_fra_esp(port)
                resultat["id"] = kort_id
            except Exception as e:
                resultat["feil"] = str(e)
            finally:
                ferdig["status"] = True
                root.after(0, oppdater_gui)  # Oppdater GUI i hovedtråd

        def oppdater_gui():
            if resultat["feil"]:
                messagebox.showerror("Feil", f"Feil ved skanning: {resultat['feil']}")
            elif resultat["id"]:
                felt.delete(0, "end")
                felt.insert(0, resultat["id"])
            else:
                messagebox.showinfo("Info", "Ingen ID ble funnet.")

        def timeout_sjekk():
            if not ferdig["status"]:
                messagebox.showwarning("Tidsavbrudd", "Ingen kort ble skannet innen tiden.")
        
        threading.Thread(target=les, daemon=True).start()
        root.after(timeout, timeout_sjekk)

    def sjekk_felter_og_kjør_funksjon(funksjon, widget_liste):
        import tkinter.messagebox
        
        for widget in widget_liste:
            # Hent verdien fra widget:
            if isinstance(widget, (tk.Entry, ttk.Combobox)):
                verdi = widget.get().strip()
                if not verdi:
                    tkinter.messagebox.showwarning("Manglende informasjon", "Vennligst fyll ut alle feltene.")
                    return False
        svar = funksjon()
        logg(f"[{threading.current_thread().name}] {svar}", ULG)
        return True

    def siste_logg_frame(root, logg_liste, antall_logg=3):
        frame = tk.Frame(root)

        tekstboks = tk.Text(frame, height=antall_logg + 1, width=80, state="disabled", bg="#f0f0f0")
        tekstboks.pack()

        def oppdater_siste_melding(ny_logg):
            tekstboks.config(state="normal")
            tekstboks.delete("1.0", tk.END)

            if ny_logg:
                # Hent de siste n loggene og snu rekkefølgen hvis ønskelig
                siste_n = reversed(ny_logg[-antall_logg:])
                tekstboks.insert(tk.END, "".join(siste_n))
            else:
                tekstboks.insert(tk.END, "Ingen loggmeldinger ennå.")

            tekstboks.config(state="disabled")

        # Oppdater første gang
        oppdater_siste_melding(logg_liste)

        return [frame, oppdater_siste_melding]

    def logg(melding, navn_på_logg_menu):
        with logg_lock:
            logg_liste = navn_på_logg_menu[1]
            tekstboks = navn_på_logg_menu[2]  # tekstboksen
            nå = datetime.now().strftime("%H:%M:%S")
            
            # Konfigurer tagger (gjøres én gang)
            tekstboks.tag_configure("tid", foreground="blue")  # Tidspunkt i grått
            tekstboks.tag_configure("melding", foreground="black")  # Melding i svart (valgfritt)

            logg_liste.append(f"{nå}; {melding}\n")
            tekstboks.config(state="normal")

            # Skriv selve meldingen med melding-tag
            tekstboks.insert("1.0", f"{melding}\n", "melding")

            # Skriv tidspunkt med tag
            tekstboks.insert("1.0", f"{nå}; ", "tid")

            tekstboks.see(tk.END)
            tekstboks.config(state="disabled")
            SLG[1](navn_på_logg_menu[1])

    def uppdate_variable(varnavn: str, verdi):
        globals()[varnavn] = verdi.get()
        logg(f"{varnavn} er nå: {globals()[varnavn]}", ULG)

    def laas_opp(root, frame):
        passord = simpledialog.askstring("Passord", "Skriv inn passord for å låse opp:", show="*")
        if passord == "elektra":  # Sett ditt passord her
            dominate_frame(root, frame)
        else:
            tk.messagebox.showerror("Feil passord", "Passordet er feil!")
        
    






    # menyer--------------------------------------------------------------------------------------------------


    def main_menu(root):
        bredde = 15
        main_frame = tk.Frame(root)
        tk.Button(main_frame, text="Avslutt", width=bredde, command=lambda: on_close()).pack(pady=1, side="bottom")
        tk.Button(main_frame, text="Logg", width=bredde, command=lambda: dominate_frame(root, [ULG[0]])).pack(pady=1)
        tk.Button(main_frame, text="Lyd kontroller", width=bredde, command=lambda: dominate_frame(root, [KM])).pack(pady=1)
        tk.Button(main_frame, text="Behandle database", width=bredde, command=lambda: laas_opp(root, [Behandle_kort_menu_frame])).pack(pady=1)
        tk.Button(main_frame, text="QLC+", width=bredde, command=lambda: dominate_frame(root, [QLC_menu])).pack(pady=1)
        tk.Button(main_frame, text="Innstillinger", width=bredde, command=lambda: dominate_frame(root, [SM])).pack(pady=1)
        #tk.Button(main_frame, text="Lys kontroller", width=bredde, command=lambda: dominate_frame(root, [Lys_menu])).pack(pady=1)
        return main_frame
    
    def logg_menu(root):
        bredde = 15
        main_frame = tk.Frame(root)
        logg_innhold = []
        tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: dominate_frame(root, [HS])).pack(pady=1)
        # Ramme som holder tekst og scrollbar
        frame = tk.Frame(main_frame)
        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        # Tekstboks
        tekstboks = tk.Text(frame, wrap=tk.WORD, yscrollcommand=scrollbar.set, width=100, height=25)
        tekstboks.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=tekstboks.yview)
        tekstboks.config(state="disabled")
        frame.pack()
        return [main_frame, logg_innhold, tekstboks]

    def settings_menu(root):
        bredde = 15
        global serverPort
        main_frame = tk.Frame(root)


        tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: dominate_frame(root, [HS])).pack(pady=1)

        server_info = tk.Frame(main_frame, bd=2, relief="groove")
        server_info.pack()
        tk.Label(server_info, text=f"Server IP: {hent_ip_adresse()}", fg="gray").pack(anchor="w")
        tk.Label(server_info, text=f"Port: {serverPort}", fg="gray").pack(anchor="w")
        tk.Label(server_info, text=f"Lydklipp path: {path_til_lydklipp}", fg="gray").pack(anchor="w")

        godta_knapp_var = tk.BooleanVar(value=godta_knapp)
        tk.Checkbutton(main_frame, text="Godta sang fra knapp", font=("Helvetica", 10), variable=godta_knapp_var, command=lambda: uppdate_variable("godta_knapp", godta_knapp_var)).pack(pady=1)

        godta_kort_var = tk.BooleanVar(value=godta_kort)
        tk.Checkbutton(main_frame, text="Godta sang fra kort", font=("Helvetica", 10), variable=godta_kort_var, command=lambda: uppdate_variable("godta_kort", godta_kort_var)).pack(pady=1)

        godta_mp3_var = tk.BooleanVar(value=godta_MP3)
        tk.Checkbutton(main_frame, text="Godta mp3-fil", font=("Helvetica", 10), variable=godta_mp3_var, command=lambda: uppdate_variable("godta_MP3", godta_mp3_var)).pack(pady=1)


        tk.Button(main_frame, text="Client manual", width=bredde, command=lambda: vis_txt_fil(Funksjoner_beskrivelse)).pack(pady=1)

        return main_frame

    def lyd_kontroll_menu(root):
        global sanger_liste
        bredde = 15

        main_frame = tk.Frame(root, bd=2)
        main_frame.pack(fill="both", expand=True)
        tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

        width = 300
        height = 500
        frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

        frame1.pack_propagate(False)
        frame2.pack_propagate(False)
        frame3.pack_propagate(False)

        # Funksjon for å spørre om passord og vise beskyttede Frames
        def avansert_kontroll_menu():
                frame2.pack(side="left", padx=5, pady=5)
                frame3.pack(side="left", padx=5, pady=5)
                avansert_knapp.forget()

        
        def tilbake():
            frame2.forget()
            frame3.forget()
            avansert_knapp.pack(pady=10)
            dominate_frame(root, [HS])

        # Knapp for å låse opp frame2 og frame3
        avansert_knapp_frame = tk.Frame(main_frame)
        avansert_knapp_frame.pack(pady=10, side="bottom")
        avansert_knapp = tk.Button(avansert_knapp_frame, text="Mer", width=bredde, command=avansert_kontroll_menu)
        avansert_knapp.pack(pady=10)

        frame1.pack(side="left", padx=5, pady=5)
        #frame2.pack(side="left", padx=5, pady=5)
        #frame3.pack(side="left", padx=5, pady=5)


        #frame 1
        underframe1 = tk.Frame(frame1, bd=2, relief="groove")
        tk.Button(underframe1, text="Legg til sang", width=bredde, command=lambda: dummy()).pack(pady=5)

        tk.Label(frame1, text=f"Musikkspiller", fg="black").pack(anchor="w", pady=5)
        
        tk.Button(frame1, text="Scan og spill sang", width=bredde, command=lambda: skann_og_spill()).pack(pady=1)
        tk.Button(frame1, text="Stopp sang", width=bredde, command=lambda: queue_song([None, False, 1.0])).pack(pady=5, side="bottom")
        tk.Button(frame1, text="Start sang", width=bredde, command=lambda: queue_song([velg_sang.get().strip(), True, float(velg_volum.get().strip()), funksjons_mapping_pause_spotify[pause_spotify.get()], velg_scene.get() ])).pack(pady=1, side="bottom")
        
        velg_sang_frame = tk.Frame(frame1)
        velg_sang_frame.pack(pady=5)

        global velg_sang
        tk.Label(velg_sang_frame, text="Sang:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        velg_sang = ttk.Combobox(velg_sang_frame, width=15, values=sanger_liste)
        velg_sang.grid(row=0, column=1, padx=5, pady=2)

        volume_liste = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        tk.Label(velg_sang_frame, text="Volum:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        velg_volum = ttk.Combobox(velg_sang_frame, width=15, values=volume_liste, state="readonly")
        velg_volum.insert(0, 1.0)
        velg_volum.grid(row=1, column=1, padx=5, pady=2)

        funksjons_mapping_pause_spotify = {"Stopp": 1, "Ikke Stopp": 0}
        tk.Label(velg_sang_frame, text="Spotify:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        pause_spotify = ttk.Combobox(velg_sang_frame, width=15, values=list(funksjons_mapping_pause_spotify.keys()), state="readonly")
        pause_spotify.insert(0, "Stopp")
        pause_spotify.grid(row=2, column=1, padx=5, pady=2)

        scene_liste = [None]
        tk.Label(velg_sang_frame, text="Scene:").grid(row=3, column=0, sticky="w", padx=5, pady=2)
        velg_scene = ttk.Combobox(velg_sang_frame, width=15, values=scene_liste)
        velg_scene.grid(row=3, column=1, padx=5, pady=2)
        
        #frame 2
        
        #frame 3

        return main_frame

    def behandle_kort_menu(root):
        global sanger_liste
        bredde = 15

        main_frame = tk.Frame(root, bd=2, relief="groove")
        main_frame.pack(fill="both", expand=True)
        tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

        width = 300
        height = 500
        frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

        frame1.pack_propagate(False)
        frame2.pack_propagate(False)
        frame3.pack_propagate(False)

        # Funksjon for å spørre om passord og vise beskyttede Frames
        def avansert_kontroll_menu():
                frame2.pack(side="left", padx=5, pady=5)
                frame3.pack(side="left", padx=5, pady=5)
                avansert_knapp.forget()
        
        def tilbake():
            frame2.forget()
            frame3.forget()
            avansert_knapp.pack(pady=10)
            dominate_frame(root, [HS])

        # Knapp for å låse opp frame2 og frame3
        avansert_knapp_frame = tk.Frame(main_frame)
        avansert_knapp_frame.pack(pady=10, side="bottom")
        avansert_knapp = tk.Button(avansert_knapp_frame, text="Mer", width=bredde, command=avansert_kontroll_menu)
        avansert_knapp.pack(pady=10)

        frame1.pack(side="left", padx=5, pady=5)
        #frame1.pack(side="left", padx=5, pady=5)
        #frame3.pack(side="left", padx=5, pady=5)

        #frame 1
        tk.Label(frame1, text=f"Behandle database", fg="black").pack(anchor="w", pady=5)
        tk.Button(frame1, text="Scan kort", width=bredde, command=lambda: skann_kort(IDe, root_frame)).pack(pady=1)

        id_navn_startsignal = tk.Frame(frame1)
        id_navn_startsignal.pack(pady=5)

        tk.Label(id_navn_startsignal, text="ID:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        IDe = tk.Entry(id_navn_startsignal, width=18)
        IDe.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(id_navn_startsignal, text="Navn:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        Navn = tk.Entry(id_navn_startsignal, width=18)
        Navn.grid(row=1, column=1, padx=5, pady=2)

        global Sang
        tk.Label(id_navn_startsignal, text="Sang:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        Sang = ttk.Combobox(id_navn_startsignal, width=15, values=sanger_liste)
        Sang.grid(row=2, column=1, padx=5, pady=2) 

        funksjons_mapping = {"Start": 1, "Stopp": 0}
        tk.Label(id_navn_startsignal, text="Funksjon:").grid(row=3, column=0, sticky="w", padx=5, pady=2)
        Funksjon = ttk.Combobox(id_navn_startsignal, width=15, values=list(funksjons_mapping.keys()), state="readonly")
        Funksjon.grid(row=3, column=1, padx=5, pady=2)  

        volume_liste = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        tk.Label(id_navn_startsignal, text="Volum:").grid(row=4, column=0, sticky="w", padx=5, pady=2)
        volume = ttk.Combobox(id_navn_startsignal, width=15, values=volume_liste, state="readonly")
        volume.grid(row=4, column=1, padx=5, pady=2)

        stopp_spotify_map = {"Stopp": 1, "Ikke Stopp": 0}
        tk.Label(id_navn_startsignal, text="Spotify:").grid(row=5, column=0, sticky="w", padx=5, pady=2)
        stopp_spotify = ttk.Combobox(id_navn_startsignal, width=15, values=list(stopp_spotify_map.keys()), state="readonly")
        stopp_spotify.grid(row=5, column=1, padx=5, pady=2)

        scene_liste = [None]
        tk.Label(id_navn_startsignal, text="Scene:").grid(row=6, column=0, sticky="w", padx=5, pady=2)
        velg_scene = ttk.Combobox(id_navn_startsignal, width=15, values=scene_liste)
        velg_scene.grid(row=6, column=1, padx=5, pady=2)



        tk.Button(frame1, text="Legg til kort", width=bredde, command=lambda: sjekk_felter_og_kjør_funksjon(lambda: db.save_card('min_database.db', IDe.get().strip(), Navn.get().strip(), Sang.get().strip(), funksjons_mapping.get(Funksjon.get().strip(), 0), volume.get().strip(), stopp_spotify_map.get(stopp_spotify.get().strip(), 0), velg_scene.get().strip()), [IDe, Navn, Funksjon, volume, stopp_spotify, velg_scene])).pack(pady=5, side="bottom")
        tk.Button(frame1, text="Slett kort", width=bredde, command=lambda: sjekk_felter_og_kjør_funksjon(lambda: db.delete_card('min_database.db', IDe.get().strip(), Navn.get().strip()), [1])).pack(pady=1, side="bottom")
        tk.Button(frame1, text="Se database", width=bredde, command=lambda: vis_database("min_database.db")).pack(pady=5, side="bottom")

        #frame 2

        #frame 3

        return main_frame

    def lys_kontroll_menu(root):
        global ESP_liste
        bredde = 15

        main_frame = tk.Frame(root, bd=2, relief="groove")
        main_frame.pack(fill="both", expand=True)
        tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

        width = 300
        height = 475
        frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

        frame1.pack_propagate(False)
        frame2.pack_propagate(False)
        frame3.pack_propagate(False)

        # Funksjon for å spørre om passord og vise beskyttede Frames
        def laas_opp():
            passord = simpledialog.askstring("Passord", "Skriv inn passord for å låse opp:", show="*")
            if passord == "elektra":  # Sett ditt passord her
                frame2.pack(side="left", padx=5, pady=5)
                frame3.pack(side="left", padx=5, pady=5)
                underframe1.pack(padx=5, pady=5)
            else:
                tk.messagebox.showerror("Feil passord", "Passordet er feil!")
        
        def tilbake():
            frame2.forget()
            frame3.forget()
            underframe1.forget()
            dominate_frame(root, [HS])
        
        def validate_spinbox_input(P):
            if P == "":
                return True
            try:
                value = int(P)
                return 0 <= value <= 255
            except ValueError:
                return False
        
        def velg_farge():
            farge = colorchooser.askcolor(title="Velg farge")
            if farge[1] is not None:
                valgt_farge.set(farge[1])  # farge[1] er hex-strengen, f.eks. "#ff0000"
                farge_visning.config(bg=farge[1])

        # Knapp for å låse opp frame2 og frame3
        avansert_knapp = tk.Button(main_frame, text="Mer", width=bredde, command=laas_opp)
        avansert_knapp.pack(pady=10, side="bottom")

        frame1.pack(side="left", padx=5, pady=5)
        #frame2.pack(side="left", padx=5, pady=5)
        #frame3.pack(side="left", padx=5, pady=5)


        #frame 1
        underframe1 = tk.Frame(frame1, bd=2, relief="groove")
        tk.Button(underframe1, text="Legg til lys", width=bredde, command=lambda: dummy()).pack(pady=5)

        tk.Label(frame1, text=f"Lysmixer", fg="black").pack(anchor="w", pady=5)
        
        tk.Button(frame1, text="Oppdater lys", width=bredde, command=lambda: dummy()).pack(pady=5, side="bottom")
        
        velg_esp_frame = tk.Frame(frame1)
        velg_esp_frame.pack(pady=5)

        tk.Label(velg_esp_frame, text="ESP:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        velg_esp = ttk.Combobox(velg_esp_frame, width=15, values=ESP_liste)
        velg_esp.grid(row=0, column=1, padx=5, pady=3)

        tk.Label(velg_esp_frame, text="Section:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        velg_section = ttk.Combobox(velg_esp_frame, width=15, values=ESP_liste)
        velg_section.grid(row=1, column=1, padx=5, pady=3)
        
        tk.Label(velg_esp_frame, text="Effekt:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        velg_effekt = ttk.Combobox(velg_esp_frame, width=15, values=ESP_liste)
        velg_effekt.grid(row=2, column=1, padx=5, pady=3)


        vcmd = root.register(validate_spinbox_input)

        tk.Label(velg_esp_frame, text="Hastighet:").grid(row=3, column=0, sticky="w", padx=5, pady=2)
        velg_hastighet = Spinbox(velg_esp_frame, from_=0, to=255, width=16, validate="key", validatecommand=(vcmd, "%P"))
        velg_hastighet.grid(row=3, column=1, padx=5, pady=3)

        tk.Label(velg_esp_frame, text="Lysstyrke:").grid(row=4, column=0, sticky="w", padx=5, pady=2)
        velg_styrke = Spinbox(velg_esp_frame, from_=0, to=255, width=16, validate="key", validatecommand=(vcmd, "%P"))
        velg_styrke.grid(row=4, column=1, padx=5, pady=3)

        tk.Label(velg_esp_frame, text="Farge:").grid(row=5, column=0, sticky="w", padx=5, pady=2)
        valgt_farge = tk.StringVar()
        farge_knapp = tk.Button(velg_esp_frame, text="Velg farge", command=velg_farge, height=1, width=10)
        farge_knapp.grid(row=5, column=1, columnspan=1, padx=5, pady=3, sticky="w")
        # Vis valgt farge i en liten boks
        farge_visning = tk.Label(velg_esp_frame, width=4, bg="white", relief="solid", bd=1)
        farge_visning.grid(row=5, column=1, padx=7, sticky="e")


        #frame 2
        tk.Label(frame2, text=f"Behandle database", fg="black").pack(anchor="w", pady=5)
        
        id_navn_startsignal = tk.Frame(frame2)
        id_navn_startsignal.pack(pady=5)

        tk.Label(id_navn_startsignal, text="MAC Adr:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        IDe = tk.Entry(id_navn_startsignal, width=18)
        IDe.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(id_navn_startsignal, text="Navn:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        Navn = tk.Entry(id_navn_startsignal, width=18)
        Navn.grid(row=1, column=1, padx=5, pady=2)


        tk.Button(frame2, text="Legg til ESP", width=bredde, command=lambda: dummy()).pack(pady=5, side="bottom")
        tk.Button(frame2, text="Slett ESP", width=bredde, command=lambda: dummy()).pack(pady=5, side="bottom")
        tk.Button(frame2, text="Se database", width=bredde, command=lambda: dummy()).pack(pady=5, side="bottom")


        #frame 3
        return main_frame

    def QLC_kontroll_menu(root):
        bredde = 15

        main_frame = tk.Frame(root, bd=2, relief="groove")
        main_frame.pack(fill="both", expand=True)
        tk.Button(main_frame, text="Tilbake", width=bredde, command=lambda: tilbake()).pack(pady=1)

        width = 300
        height = 500
        frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame2 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
        frame3 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")

        frame1.pack_propagate(False)
        frame2.pack_propagate(False)
        frame3.pack_propagate(False)

        # Funksjon for å spørre om passord og vise beskyttede Frames
        def avansert_kontroll_menu():
                frame2.pack(side="left", padx=5, pady=5)
                frame3.pack(side="left", padx=5, pady=5)
                avansert_knapp.forget()

        def tilbake():
            frame2.forget()
            frame3.forget()
            avansert_knapp.pack(pady=10)
            dominate_frame(root, [HS])

        # Knapp for å låse opp frame2 og frame3
        avansert_knapp_frame = tk.Frame(main_frame)
        avansert_knapp_frame.pack(pady=10, side="bottom")
        avansert_knapp = tk.Button(avansert_knapp_frame, text="Mer", width=bredde, command=avansert_kontroll_menu)
        avansert_knapp.pack(pady=10)

        frame1.pack(side="left", padx=5, pady=5)
        #frame2.pack(side="left", padx=5, pady=5)
        #frame3.pack(side="left", padx=5, pady=5)


        #frame 1
        tk.Label(frame1, text=f"QLC+", fg="black").pack(anchor="w", pady=5)
        
        tk.Button(frame1, text="send signal", width=bredde, command=lambda: send_osc_til_qlc(velg_kanal_navn.get(), int(kanal_verdi.get()))).pack(pady=5, side="bottom")
        
        velg_sang_frame = tk.Frame(frame1)
        velg_sang_frame.pack(pady=5)

        tk.Label(velg_sang_frame, text="Kanal navn:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        velg_kanal_navn = ttk.Entry(velg_sang_frame, width=15)
        velg_kanal_navn.grid(row=0, column=1, padx=5, pady=2)

        tk.Label(velg_sang_frame, text="Verdi:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        kanal_verdi = ttk.Entry(velg_sang_frame, width=15)
        kanal_verdi.grid(row=1, column=1, padx=5, pady=2)

        #frame 2
        
        #frame 3

        return main_frame

    HS = main_menu(root)
    SM = settings_menu(root)
    ULG = logg_menu(root)
    KM = lyd_kontroll_menu(root)
    Behandle_kort_menu_frame = behandle_kort_menu(root)
    Lys_menu = lys_kontroll_menu(root)
    SLG = siste_logg_frame(root_frame, ULG[1])
    QLC_menu = QLC_kontroll_menu(root)

    SLG[0].pack(pady=10, side="bottom")

    Thread3 = threading.Thread(target=QLC_pluss_manager, daemon=True, name="QLC+ Manager")
    Thread2 = threading.Thread(target=musikkspiller, daemon=True, name="Musikkspiller")
    Thread1 = threading.Thread(target=Server, daemon=True, name="Server")
    Thread1.start()
    Thread2.start()
    Thread3.start()

    dominate_frame(root, [HS])


def start_up_menu(root):
    bredde = 15

    main_frame = tk.Frame(root, bd=2)
    main_frame.pack(fill="both", expand=True)

    # Funksjoner
    def start_server():
        global serverPort
        global QLC_IP
        global QLC_port

        serverPort = int(server_port.get())
        QLC_IP = QLC_Server_IP.get()
        QLC_port = int(QLC_Server_port.get())

        main()
        

    # OK-knapp
    tk.Button(main_frame, text="OK", width=bredde, command=start_server).pack(pady=10)

    width = 330
    height = 475
    frame1 = tk.Frame(main_frame, width=width, height=height, bd=2, relief="groove")
    frame1.pack(side="left", padx=5, pady=5)
    frame1.pack_propagate(False)

    # Frame 1
    tk.Label(frame1, text="Initialisering", fg="black").pack(anchor="w", pady=5)

    # Legg inn portinput i en egen underframe for struktur
    port_frame = tk.Frame(frame1)
    port_frame.pack(anchor="w", pady=2)

    tk.Label(port_frame, text="Server port:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
    server_port = ttk.Entry(port_frame, width=15)
    server_port.grid(row=0, column=1, padx=5, pady=2)
    server_port.insert(0, serverPort)

    tk.Label(port_frame, text="QLC+ Server IP:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
    QLC_Server_IP = ttk.Entry(port_frame, width=15)
    QLC_Server_IP.grid(row=1, column=1, padx=5, pady=2)
    QLC_Server_IP.insert(0, QLC_IP)

    tk.Label(port_frame, text="QLC+ Server Port:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
    QLC_Server_port = ttk.Entry(port_frame, width=15)
    QLC_Server_port.grid(row=2, column=1, padx=5, pady=2)
    QLC_Server_port.insert(0, QLC_port)

    return main_frame



Start_menu = start_up_menu(root)
dominate_frame(root, [Start_menu])


root_frame.after(200, sett_oppgavelinjeikon)
root_frame.mainloop()

