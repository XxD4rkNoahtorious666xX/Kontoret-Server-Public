#serverporten
serverPort = 12000

#path til mappen som inneholder lydklippene
path_til_lydklipp = "C:\\Users\\noah\\Downloads\\Sanger_kontoret\\"

#filnavn til appikon
Icon = "ElektraLogo-01.ico"

#komunikasjon med QLC+
QLC_IP = "127.0.0.1"
QLC_port = 7700 

#broadcast port
broadcast_port = 5005