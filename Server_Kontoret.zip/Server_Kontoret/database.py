import sqlite3
import threading
import time

# For å legge til kort i databasen, bruk funksjonen: save_card(Database, KortID, KortNavn, Sang, StartToggle)
# For å slette kort fra databasen, bruk funksjonen: delete_card(Database, KortID, KortNavn)
# For å avlese hele databasen, bruk funksjonen: Hent_tabell(Database)


behandle_database_lock = threading.Lock()


def Make_a_table(Database):
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()
    

    # Lag en tabell
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS kort (
            id INTEGER PRIMARY KEY,
            KortID TEXT,
            KortNavn TEXT,
            Sang TEXT,
            Start BOOL,
            volum REAL,      
            Stopp_spotify BOOL,
            Scene TEXT       
            
        )
    ''')

    conn.commit()
    conn.close()

def ToLower(tekst):
    return tekst.lower()

def Append_database(Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene):
    # Lag (eller koble til) en database
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    # Lag en tabell
    Make_a_table(Database)
    
    # Legg til en rad
    cursor.execute('INSERT INTO kort (KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene) VALUES (?, ?, ?, ?, ?, ?, ?)', (KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene))

    # Lagre endringer og lukk
    conn.commit()
    conn.close()


def Skriv_ut_tabell(Database):
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    # Hent alle rader fra tabellen
    cursor.execute('SELECT * FROM kort')
    rader = cursor.fetchall()

    # Skriv ut med kolonnenavn og pene rader
    print("ID | KortID   | KortNavn | Sang      | Start")
    print("---|----------|----------|-----------|------")
    for rad in rader:
        print(f"{rad[0]:<3}| {rad[1]:<9}| {rad[2]:<9}| {rad[3]:<10}| {rad[4]}")

    conn.close()


def hent_sang_fra_kortid(Database, kortID):
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    cursor.execute("SELECT Sang, Start, volum, Stopp_spotify, Scene FROM kort WHERE KortID = ?", (kortID,))
    rad = cursor.fetchone()

    conn.close()

    if rad:
        return rad[0], rad[1], rad[2], rad[3], rad[4]  # Returnerer selve sangnavnet
    else:
        return None  # Fant ikke kortet

def Sjekk_KortID_database(Database, KortID):
    # Lag (eller koble til) en database
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    # Sjekk om personen allerede finnes
    cursor.execute('SELECT * FROM kort WHERE KortID = ?', (KortID,))
    resultat = cursor.fetchone()

    if resultat:
        cursor.close()
        return True, resultat[0]
    else:
        cursor.close()
        return False, None

def Sjekk_KortNavn_database(Database, KortNavn):
    # Lag (eller koble til) en database
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    # Sjekk om personen allerede finnes
    cursor.execute('SELECT * FROM kort WHERE KortNavn = ?', (KortNavn,))
    resultat = cursor.fetchone()

    if resultat:
        cursor.close()
        return True, resultat[0]
    else:
        cursor.close()
        return False, None


def update_Database(rad, Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene):
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    cursor.execute('''
    UPDATE kort
    SET KortID = ?,
        KortNavn = ?,
        Sang = ?,
        Start = ?,
        volum = ?,
        stopp_spotify = ?,
        Scene = ?
    WHERE id = ?
    ''', (KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene, rad))

    conn.commit()
    conn.close()

def Add_to_Database(Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene):
    with behandle_database_lock:
        Make_a_table(Database)
        if Sjekk_KortID_database(Database, KortID)[0]:
            #print("oppdaterer database")
            update_Database(Sjekk_KortID_database(Database, KortID)[1], Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene)

        elif(Sjekk_KortID_database(Database, KortID)[0] == False):
            #print("legger til i database")
            Append_database(Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene)

def save_card(Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene):
    Make_a_table(Database)
    KortNavn = ToLower(KortNavn)
    if (Sjekk_KortID_database(Database, KortID)[0] == True):
        Add_to_Database(Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene)
        return "Kort-ID finnes allerede, verdier oppdatert"
    
    elif(Sjekk_KortNavn_database(Database, KortNavn)[0] == True):
        return "Dette navnet er allerede tatt, kort ikke lagret"
    
    Add_to_Database(Database, KortID, KortNavn, Sang, Start, volum, stopp_spotify, Scene)

    if (Sjekk_KortID_database(Database, KortID)[0] == True):
        return f"Kortet: [{KortID}, {KortNavn}] ble lagt til i databasen"
    else:
        return "Kortet ble ikke lagt til i databasen"


def slett_KortID(Database, KortID):
    with behandle_database_lock:
        conn = sqlite3.connect(Database)
        cursor = conn.cursor()

        cursor.execute("DELETE FROM kort WHERE KortID = ?", (KortID,))

        conn.commit()
        conn.close()

def delete_card_by_id(Database, KortID):
    #print("sletter kort")
    if (Sjekk_KortID_database(Database, KortID)[0] == False):
        slett_KortID(Database, KortID)
        return "Kortet finnes ikke i databasen"
        
    slett_KortID(Database, KortID)
    #print(Sjekk_KortID_database(Database, KortID)[0])

    if (Sjekk_KortID_database(Database, KortID)[0] == False):
        return "kortet ble slettet fra databasen"
    else:
        return "kortet ble ikke slettet fra databasen"


def slett_KortNavn(Database, KortNavn):
    with behandle_database_lock:
        conn = sqlite3.connect(Database)
        cursor = conn.cursor()

        cursor.execute("DELETE FROM kort WHERE KortNavn = ?", (KortNavn,))

        conn.commit()
        conn.close()

def delete_card_by_name(Database, KortNavn):
    #print("sletter kort")
    if (Sjekk_KortNavn_database(Database, KortNavn)[0] == False):
        slett_KortNavn(Database, KortNavn)
        return "Kortet finnes ikke i databasen"
    
    slett_KortNavn(Database, KortNavn)
    #print(Sjekk_KortNavn_database(Database, KortNavn)[0])

    if (Sjekk_KortNavn_database(Database, KortNavn)[0] == False):
        return "Kortet ble slettet fra databasen"
    else:
        return "Kortet ble ikke slettet fra databasen"


def delete_card(Database, KortID, KortNavn):
    KortNavn = ToLower(KortNavn)
    if Sjekk_KortID_database(Database, KortID)[0]:
        slett_KortID(Database, KortID)    
        return f"Slettet kort med ID: {KortID}"
    if Sjekk_KortNavn_database(Database, KortNavn)[0]:
        slett_KortNavn(Database, KortNavn)
        return f"Slettet kort med Navn: {KortNavn}"
    return f"Forsøkte å slette: [{KortID}, {KortNavn}], men kortet finnes ikke"



def Hent_tabell(Database):
    conn = sqlite3.connect(Database)
    cursor = conn.cursor()

    Make_a_table(Database)

    cursor.execute('SELECT * FROM kort')
    rader = cursor.fetchall()

    conn.close()
    return rader  # Ikke tekst, men en liste av tuples


#Add_to_Database('min_database.db', '1237', 'Trond', 'Humble', True)
#slett_KortNavn('min_database.db', 'Noah')
#delete_card_by_name('min_database.db', 'Noah')

#Skriv_ut_tabell('min_database.db')
