import serial
import serial.tools.list_ports

def finn_esp_port():
    """Returnerer COM-porten til ESP hvis funnet, ellers None"""
    porter = serial.tools.list_ports.comports()
    for port in porter:
        if "CP210" in port.description or "CH340" in port.description or "USB Serial" in port.description:
            return port.device
    return None

def les_fra_esp(port):
    """Leser kontinuerlig fra ESP på gitt port"""
    try:
        with serial.Serial(port, 115200) as ser:
            #print(f"[ESP CONNECTED] Leser fra {port}")
            
            data = ser.readline().decode(errors="ignore").strip()
            if data:
                #print(f"[ESP] {data}")
                return data
            
    except serial.SerialException:
        #print(f"[DISCONNECTED] Mistet kontakt med {port}")
        return


#print(les_fra_esp(finn_esp_port()))